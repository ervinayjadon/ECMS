﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECMS.Models;
using ECMS.Models.EntityEdmx;

namespace ECMS.DAL
{
    public interface IContacts
    {
        // Get All Contacts
        IEnumerable<ContactModel> GetAllContacts();

        // Get Contact By Id
        Contact GetContactById(int Id);
        
        // Add New Contact
        Contact AddContact(Contact contact);
        
        // Update Contact
        int UpdateContact(Contact contact);

        // Delete Contact
        void Delete(int Id);
    }
}
