﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ECMS.Models;
using ECMS.Models.EntityEdmx;

namespace ECMS.DAL
{
    public class ContactsLib : IContacts
    {
        ECMSDBEntities dbContext = new ECMSDBEntities();

        /// <summary>
        /// Gets All Contacts
        /// </summary>
        /// <returns>Contact List</returns>
        public IEnumerable<ContactModel> GetAllContacts()
        {
            List<ContactModel> listOfUsers = new List<ContactModel>();

            foreach (var contact in dbContext.Contacts)
            {
                ContactModel contactModel = new ContactModel();
                contactModel.id = contact.Id;
                contactModel.FirstName = contact.FirstName;
                contactModel.LastName = contact.LastName;
                contactModel.Email = contact.Email;
                contactModel.PhoneNumber = contact.PhoneNumber;
                contactModel.Status = contact.Status;
                listOfUsers.Add(contactModel);
            }
            IEnumerable<ContactModel> contacts = listOfUsers;

            return contacts;
        }

        /// <summary>
        /// Get Contact by ID
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>Contact Detail</returns>
        public Contact GetContactById(int id)
        {
            IQueryable<Contact> contact = dbContext.Contacts.Where(x => x.Id == id);
            return contact.FirstOrDefault();
        }
        
        /// <summary>
        /// Add New Contact
        /// </summary>
        /// <param name="contact">Contact</param>
        public Contact AddContact(Contact contact)
        {
            var addedContact = dbContext.Contacts.Add(contact);
            dbContext.SaveChanges();
            return addedContact;
        }

        /// <summary>
        /// Updates Existing Contact
        /// </summary>
        /// <param name="contact">Contact</param>
        /// <returns>result</returns>
        public int UpdateContact(Contact contact)
        {
            Contact objContact = dbContext.Contacts.FirstOrDefault(x => x.Id == contact.Id);
            objContact.FirstName = contact.FirstName.Trim();
            objContact.LastName = contact.LastName.Trim();
            objContact.Email = contact.Email.Trim();
            objContact.PhoneNumber = contact.PhoneNumber.Trim();
            objContact.Status = contact.Status.Trim();
            return dbContext.SaveChanges();
        }

        /// <summary>
        /// Deletes Contact
        /// </summary>
        /// <param name="ID">ID</param>
        public void Delete(int Id)
        {
            Contact contact = dbContext.Contacts.FirstOrDefault(x => x.Id == Id);
            dbContext.Contacts.Remove(contact);
            dbContext.SaveChanges();
        }
    }
}