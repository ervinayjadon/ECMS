﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using ECMS.Models;
using Newtonsoft.Json;

namespace ECMS.Controllers
{
    public class HomeController : Controller
    {
        Uri baseURI = new Uri(System.Configuration.ConfigurationManager.AppSettings["WebAPICallURL"]);

        public ActionResult Index()
        {          
            return View();
        }

        public ActionResult ListContacts()
        {
            HttpClient client = new HttpClient();
            var response = client.GetStringAsync(baseURI + "/api/contactapi/").Result;
            List<ContactModel> listOfContats = (List<ContactModel>)JsonConvert.DeserializeObject<IEnumerable<ContactModel>>(response);
            return View(listOfContats);
        }

        public ActionResult AddContact()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddContact(ContactModel cm)
        {
            cm.Status = "Active";
            HttpClient client = new HttpClient();
            var response = client.PostAsJsonAsync(baseURI + "/api/contactapi/", cm).Result;

            return RedirectToAction("ListContacts", "Home");
        }

        public ActionResult EditContact(int id)
        {
            HttpClient client = new HttpClient();
            var response = client.GetStringAsync(baseURI + "/api/contactapi/" + id).Result;
            ContactModel contacts = (ContactModel)JsonConvert.DeserializeObject<ContactModel>(response);
            return View(contacts);
        }

        [HttpPost]
        public ActionResult EditContact(ContactModel cm)
        {
            HttpClient client = new HttpClient();
            var response = client.PutAsJsonAsync(baseURI + "/api/contactapi/", cm).Result;

            return RedirectToAction("ListContacts", "Home");
        }

        public ActionResult DeleteContact(int id)
        {
            HttpClient client = new HttpClient();
            var response = client.GetStringAsync(baseURI + "/api/contactapi/" + id).Result;
            ContactModel contacts = (ContactModel)JsonConvert.DeserializeObject<ContactModel>(response);
            return View(contacts);
        }

        [HttpPost]
        public ActionResult DeleteContact(ContactModel cm)
        {
            HttpClient client = new HttpClient();
            var response = client.DeleteAsync(baseURI + "/api/contactapi/" + cm.id).Result;

            return RedirectToAction("ListContacts", "Home");
        }

        public ActionResult StatusChange(int id, string newStatus)
        {
            HttpClient client = new HttpClient();
            var response = client.GetStringAsync(baseURI + "/api/contactapi/" + id).Result;
            ContactModel contacts = (ContactModel)JsonConvert.DeserializeObject<ContactModel>(response);
            contacts.Status = newStatus;
            
            client = new HttpClient();
            var response1 = client.PutAsJsonAsync(baseURI + "/api/contactapi/", contacts).Result;

            return RedirectToAction("ListContacts", "Home");            
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            string action = filterContext.RouteData.Values["action"].ToString();
            Exception ex = filterContext.Exception;
            filterContext.ExceptionHandled = true;
            filterContext.Result = new ViewResult() { ViewName = "Error" };
        }
    }
}
