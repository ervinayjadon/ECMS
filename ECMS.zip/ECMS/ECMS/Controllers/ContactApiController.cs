﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ECMS.DAL;
using ECMS.Models;
using ECMS.Models.EntityEdmx;

namespace ECMS.Controllers
{
    public class ContactApiController : ApiController
    {
        IContacts _repository = new ContactsLib();

        // GET api/contactapi
        [HttpGet]
        public IEnumerable<ContactModel> Get()
        {
            return _repository.GetAllContacts();
        }

        // GET api/contactapi/5
        [HttpGet]
        public Contact Get(int id)
        {
            Contact contact = _repository.GetContactById(id);
            return contact;
        }

        // POST api/contactapi
        [HttpPost]
        public void Post(Contact contact)
        {
            try
            {
                _repository.AddContact(contact);
            }
            catch
            {
 
            }
        }

        // PUT api/contactapi/5
        [HttpPut]
        public void Put(Contact contact)
        {
            if (_repository.UpdateContact(contact) == 0)
                throw new HttpResponseException(HttpStatusCode.NotFound);
        }

        // DELETE api/contactapi/5
        [HttpDelete]
        public void Delete(int id)
        {
            _repository.Delete(id);
        }
    }
}
