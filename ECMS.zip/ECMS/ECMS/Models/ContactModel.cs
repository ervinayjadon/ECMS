﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ECMS.Models
{
    public class ContactModel
    {
        public int id { get; set; }

        [Required]
        [Display(Name = "First Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Invalid entry, Input accepts only alphabets without spaces")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Invalid entry, Input accepts only alphabets without spaces")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Email Address")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        [Range(1000000000, 9999999999, ErrorMessage = "Input must be only numbers and should be of 10 digits")]
        public string PhoneNumber { get; set; }

        public string Status { get; set; }
    }
}